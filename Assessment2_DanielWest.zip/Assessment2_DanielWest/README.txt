Number Keys 1-8 change the AI to the respective behavior.

Implemented Behaviours:
1 - Flock
2 - Seek
3 - Flee
4 - Arrive
5 - Evade
6 - Pursuit
7 - Follow Leader
8 - Wander
0 - Stop movement

Arrow keys to move the player

Left click to spawn more fish into the flock
